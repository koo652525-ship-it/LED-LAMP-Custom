package com.example.ledcarcustom

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LedLampApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LedLampApp() {
    var tab by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf("Rainbow Flow") }
    val tabs = listOf("Light Modes", "Welcome", "RGB", "About")
    val modes = listOf("Rainbow Flow", "Color Wave", "Neon Pulse", "Meteor Trail",
        "Fire Flicker", "Ocean Drift", "Aurora", "Strobe", "Breathing", "Chase",
        "Color Cycle", "Twinkle", "Comet", "Gradient Sweep", "Sunset Fade") +
        (16..100).map { "Custom Light Mode $it" }
    val welcomes = listOf("Welcome Rainbow", "Welcome Wave", "Welcome Pulse",
        "Welcome Comet", "Welcome Sparkle", "Welcome Sunrise", "Welcome Color Sweep",
        "Welcome Chase") + (9..100).map { "Welcome Animation $it" }

    MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF66D9FF),
        secondary = Color(0xFFB388FF), background = Color(0xFF080B14),
        surface = Color(0xFF121827))) {
        Scaffold(topBar = {
            TopAppBar(title = { Column {
                Text("LED LAMP CUSTOM", fontWeight = FontWeight.Bold)
                Text("Custom effects interface", fontSize = 12.sp)
            } }, colors = TopAppBarDefaults.topAppBarColors(
                containerColor = Color(0xFF101827), titleContentColor = Color.White))
        }, containerColor = Color(0xFF080B14)) { pad ->
            Column(Modifier.fillMaxSize().padding(pad)) {
                Row(Modifier.fillMaxWidth().padding(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    tabs.forEachIndexed { i, label ->
                        FilterChip(selected = tab == i, onClick = { tab = i },
                            label = { Text(label) })
                    }
                }
                when (tab) {
                    0 -> ModeList("New Light Modes", modes, selected) { selected = it }
                    1 -> ModeList("Welcome Animations", welcomes, selected) { selected = it }
                    2 -> RgbPanel()
                    else -> AboutPanel()
                }
            }
        }
    }
}

@Composable
fun ModeList(title: String, entries: List<String>, selected: String, choose: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 14.dp)) {
        Text(title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(vertical = 10.dp))
        Box(Modifier.fillMaxWidth().height(100.dp).background(
            Brush.horizontalGradient(listOf(Color.Cyan, Color(0xFF9B5CFF), Color(0xFFFF3D81))),
            RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) {
            Text("PREVIEW • $selected", color = Color.White, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(entries) { entry ->
                Card(onClick = { choose(entry) }, modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor =
                        if (entry == selected) Color(0xFF24344D) else Color(0xFF141D2D))) {
                    Row(Modifier.fillMaxWidth().padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Text(entry, color = Color.White, modifier = Modifier.weight(1f))
                        if (entry == selected) Text("SELECTED", color = Color.Cyan, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun RgbPanel() {
    var r by remember { mutableFloatStateOf(.7f) }
    var g by remember { mutableFloatStateOf(.25f) }
    var b by remember { mutableFloatStateOf(1f) }
    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("RGB CUSTOM", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Box(Modifier.fillMaxWidth().height(120.dp).background(Color(r, g, b), RoundedCornerShape(16.dp)))
        Text("Red", color = Color.White); Slider(r, { r = it })
        Text("Green", color = Color.White); Slider(g, { g = it })
        Text("Blue", color = Color.White); Slider(b, { b = it })
        Text("Preview only — controller connection is not implemented yet.", color = Color.LightGray)
    }
}

@Composable
fun AboutPanel() {
    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("About this build", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text("Includes 100 light-mode entries and 100 welcome-animation entries.", color = Color.White)
        Text("These are currently app previews. They do not send commands to the original LED controller yet.", color = Color(0xFFFFD180))
        Text("The original controller's Bluetooth protocol must be identified before real LED control can be added. No extra hardware is assumed.", color = Color.LightGray)
    }
}
