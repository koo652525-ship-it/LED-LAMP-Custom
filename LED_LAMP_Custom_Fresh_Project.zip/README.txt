LED LAMP Custom Android starter
Open LedCarCustomApp in Android Studio with JDK 17.
Build > Build APK(s).

This starter includes 100 light-mode entries and 100 welcome-animation entries.
The UI is a preview only; Bluetooth communication with the original controller is not implemented.
The controller protocol must be identified before new effects can run on real LEDs.
